import { Component, Service } from '@angular/core';
import { Users } from '../servicc';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';


@Component({
  imports: [CommonModule],
  selector: 'app-productlist',
  styleUrl: './productlist.css',
  templateUrl: './productlist.html',
  providers:[Users]
})
export class Productlist {
  data:any[]=[];


  constructor(private userservice : HttpClient){
    
  }

  get_data(){

    this.userservice.get<any[]>('https://fakestoreapi.com/products').subscribe({

      next:(res)=>{
        this.data=res;
        console.log(res);
        
      },
      error:(err)=>{
        console.log(err);
        
      },
      complete:()=>{
        console.log("Everything is okkkkk");
        
      }

    })
    
  }

  ngOnInit():void{
    this.get_data();
  }
}
